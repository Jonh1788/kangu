import React, { useState } from 'react';
import { Link, router, usePage } from '@inertiajs/react';
import { Banknote, Home, Landmark, LogOut, Users } from 'lucide-react';

export default function Deposito({auth}) {
    const { props } = usePage();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        nome: '',
        cpf: '',
        valor: ''
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleDeposito = (e) => {
        setLoading(true);
        e.preventDefault();
        axios.post('/depositar', formData)
            .then((response) => {
                router.visit(route('deposito.pix', {pix_key: response.data.pix_key, transactionId: response.data.transactionId}));
                setFormData({
                    nome: '',
                    cpf: '',
                    valor: ''
                });
            })
            .catch((error) => {
                alert('Erro ao realizar depósito!');
                console.error(error);
            })
            .finally(()=>{
                setLoading(false);
            
            })
    };

    const handleQuickSelect = (valor) => {
        setFormData({
            ...formData,
            valor
        });
    };

    return (
        <main>
            <div className="bg-gradient-to-b from-[#7C30F2] to-[#CD0000] absolute inset-0 -z-[10]"></div>
            <img src="/background-2.png" alt="" className="absolute inset-0 object-cover w-full h-full -z-[9]" />
            <div className="bg-[#F29B30] w-max mt-4 py-2 pr-4 rounded-r-md text-white font-bold">
                Saldo: R${auth.user.saldo},00
            </div>
            <div className="h-[75vh] w-[90vw] bg-[#7C30F2]/60 mx-auto mt-8 rounded-lg backdrop-blur-sm text-white text-center flex flex-col gap-16 ">
                <div className="mt-4 flex flex-col items-center">
                    <h1 className="font-bold text-xl">Depósito</h1>
                    <p className="text-sm">
                        Transforme seus depósitos PIX em momentos instantâneos de alegria e praticidade! Aproveite o bônus especial em cada transação!
                    </p>
                    {loading && <div className='size-4 -mb-6 border-2 border-black border-t-transparent rounded-full animate-spin'/>}
                </div>
                
                <form onSubmit={handleDeposito} className="flex flex-col gap-3 px-2 placeholder:text-sm -mt-8">
                    <input 
                        type="text" 
                        name="nome"
                        placeholder="Nome completo" 
                        className="w-full placeholder:text-sm rounded-lg text-black text-sm"
                        value={formData.nome}
                        onChange={handleChange}
                    />
                    <input 
                        type="text" 
                        name="cpf"
                        maxLength={11}
                        placeholder="CPF" 
                        className="w-full placeholder:text-sm rounded-lg text-black text-sm"
                        value={formData.cpf}
                        onChange={handleChange}
                    />
                    <input 
                        type="text" 
                        name="valor"
                        placeholder="Valor da transação" 
                        className="w-full placeholder:text-sm rounded-lg text-black text-sm"
                        value={formData.valor}
                        onChange={handleChange}
                    />
                    <div className="flex gap-2 w-full mt-2">
                        <button 
                            type="button" 
                            className="bg-[#FF8A00] flex-col shadowPersonalizado h-20 w-full rounded-2xl flex items-center justify-center font-bold text-white relative"
                            onClick={() => handleQuickSelect('20')}
                        >
                            <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0" />
                            <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8" />
                            R$20
                            <p className="text-xs">Sem bônus</p>
                        </button>

                        <button 
                            type="button" 
                            className="bg-[#FF8A00] flex-col shadowPersonalizado h-20 w-full rounded-2xl flex items-center justify-center font-bold text-white relative"
                            onClick={() => handleQuickSelect('25')}
                        >
                            <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0" />
                            <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8" />
                            R$25
                            <p className="text-xs">Armadura de espinho</p>
                        </button>

                        <button 
                            type="button" 
                            className="bg-[#3EB605] flex-col shadowPersonalizado h-20 w-full rounded-2xl flex items-center justify-center font-bold text-white relative animate-bigger"
                            onClick={() => handleQuickSelect('30')}
                        >
                            <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0" />
                            <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8" />
                            R$30
                            <p className="text-xs">Pulo duplo</p>
                            <div className="absolute w-full bg-[#7C30F2] -top-4 h-min rounded-t-md text-xs">
                                Mais comprado
                            </div>
                        </button>

                        <button 
                            type="button" 
                            className="bg-[#FF8A00] flex-col shadowPersonalizado h-20 w-full rounded-2xl flex items-center justify-center font-bold text-white relative"
                            onClick={() => handleQuickSelect('50')}
                        >
                            <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0" />
                            <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8" />
                            R$50
                            <p className="text-xs">2x mais tempo no fogo</p>
                        </button>
                    </div>
                    <button type="submit" className="bg-[#30B3F2] flex-col shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative">
                        <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0" />
                        <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8" />
                        Depositar
                    </button>
                </form>
            </div>

            <footer className="fixed bottom-0 w-full h-12 bg-[#7C30F2]/60 backdrop-blur-sm flex items-center justify-between px-8 text-slate-300">
                <Link href="/dashboard">
                    <Home />
                </Link>
                <Link href="/deposito" className="rounded-full bg-[#7C30F2]/60 backdrop-blur-sm border-[4px] border-[#CD0000] p-2 -translate-y-6 
                before:absolute before:bg-transparent before:size-4 before:-left-5 
                before:rounded-tr-[70%] before:top-5 before:shadow-[0_-10px_0_0_#CD0000] 
                after:absolute after:bg-transparent after:size-4 after:-right-5 
                after:rounded-tl-[70%] after:top-5 after:shadow-[0_-10px_0_0_#CD0000]">
                    <Landmark />
                </Link>
                <Link href="/saque">
                    <Banknote />
                </Link>
                <Link href="/afiliados">
                    <Users />
                </Link>
                <Link href="/logout">
                    <LogOut />
                </Link>
            </footer>
        </main>
    );
}
