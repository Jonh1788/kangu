import { Link, router, usePage } from "@inertiajs/react";
import { Banknote, Home, Landmark, LogOut, Users } from "lucide-react";
import { useState } from "react";

export default function Dashboard ({auth, token}) {
    const irParaJogo = (valor) => {
        if(auth.user.saldo < valor){
            router.visit('/deposito')
        }
        
        var dados = {
            saldo: auth.user.saldo - valor,
            token: token,
            email: auth.user.email
        }

        console.log(dados)
        axios.post('/game', dados).then((response) => {
            window.location.href = '/game?aposta=' + valor 
        
        }).catch((error) => {
            console.log(error)
        }
        )
    }
    return(
        <main>
            <div className="bg-gradient-to-b from-[#7C30F2] to-[#CD0000] absolute inset-0 -z-[10]"></div>
            <img src="/background-2.png" alt="" className="absolute inset-0 object-cover w-full h-full -z-[9]" />
            <div className="bg-[#F29B30] w-max mt-4 py-2 pr-4 rounded-r-md text-white font-bold">
                Saldo: R${auth.user.saldo},00
            </div>
            <div className="h-[75vh] w-[90vw] bg-[#7C30F2]/60 mx-auto mt-8 rounded-lg backdrop-blur-sm text-white text-center flex flex-col gap-16 ">
                <div className="mt-4">
                    <h1 className="font-bold text-xl">Vamos jogar!</h1>
                    <p className="text-sm">Escolha um valor abaixo:</p>
                </div>
                <div className="flex gap-2 px-2">
                    <button onClick={() => irParaJogo(1)} className="bg-[#3EB605] shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative" href="#">
                    <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0"/>
                    <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8"/>
                    R$1,00
                </button>
                <button onClick={() => irParaJogo(5)} className="bg-[#3EB605] shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative" href="#">
                    <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0"/>
                    <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8"/>
                    R$5,00
                </button>
               
                </div>

                <div className="flex flex-col gap-2 -mt-8">
                    <h1>Outras opções:</h1>
                    <div className="flex flex-col gap-4 px-2">
                        
                        <button onClick={() => router.visit('/deposito')} className="bg-[#30B3F2] shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative" href="#">
                        <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0"/>
                        <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8"/>
                        Depositar
                        </button>

                        <button onClick={() => router.visit('/demo')} className="bg-[#54859D] shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative" href="#">
                        <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0"/>
                        <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8"/>
                        Testar
                        </button>


                        <button onClick={() => router.visit('/afiliados')} className="bg-[#CD0000] shadowPersonalizado h-12 w-full rounded-2xl flex items-center justify-center font-bold text-white relative" href="#">
                        <div className="clip1 size-8 bg-white/30 absolute left-0 rotate-45 top-0"/>
                        <div className="clip2 size-3 bg-white/30 absolute left-1 rotate-45 top-8"/>
                        R$50 Grátis
                        </button>

                    </div>

                </div>
                
            </div>

            <footer className="fixed bottom-0 w-full h-12 bg-[#7C30F2]/60 backdrop-blur-sm flex items-center justify-between px-8 text-slate-300">
            <Link href="/dashboard" className="
                    rounded-full bg-[#7C30F2]/60 backdrop-blur-sm border-[4px] border-[#CD0000] p-2 -translate-y-6 
                    before:absolute before:bg-transparent before:size-4 before:-left-5 
                    before:rounded-tr-[70%] before:top-5 before:shadow-[0_-10px_0_0_#CD0000] 
                    after:absolute after:bg-transparent after:size-4 after:-right-5 
                    after:rounded-tl-[70%] after:top-5 after:shadow-[0_-10px_0_0_#CD0000]">
                        <Home />
                    </Link>
                    <Link href="/deposito" >
                        <Landmark />
                    </Link>
                    <Link href="/saque" >
                        <Banknote />
                    </Link>
                    <Link href="/afiliados">
                        <Users />
                    </Link>
                    <Link href="/logout">
                        <LogOut />
                    </Link>        
            </footer>
        </main>
    )
}